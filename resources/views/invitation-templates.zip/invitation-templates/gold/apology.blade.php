{{-- ============================ APOLOGY ============================ --}}
@php
    preg_match_all('/[^។]+។?/u', (string) $w['apology'], $m);
    $lines = array_values(array_filter(array_map('trim', $m[0] ?? [])));
@endphp
<section class="cream ap" id="apology">
    <div class="g-bgimg on" data-bg="{{ $bg('apology') }}" data-eager style="z-index:0;--bo:1"></div>
    <div class="veil" aria-hidden="true"></div>
    <div class="petals" aria-hidden="true">
        @for ($i = 0; $i < 8; $i++)
            <i
                style="left:{{ ($i * 47 + 8) % 100 }}%;width:11px;height:15px;animation-duration:{{ 11 + ($i % 4) * 3 }}s;animation-delay:{{ ($i % 6) * 1.8 }}s;--dx:{{ (($i % 5) - 2) * 34 }}px;--rot:{{ ($i % 2 ? 1 : -1) * (220 + $i * 25) }}deg"></i>
        @endfor
    </div>

    <div class="z2" id="ap">
        {!! $title($K['apology'], 'dark') !!}
        <div class="ap-card-w">
            <div class="gold-card ap-c">
                <div class="gold-card-in" style="padding-bottom:2rem">
                    {!! $corner('tl', 'gcn', 44) !!}{!! $corner('tr', 'gcn', 44) !!}{!! $corner('bl', 'gcn', 44) !!}{!! $corner('br', 'gcn', 44) !!}
                    <svg aria-hidden="true" viewBox="0 0 80 80" width="64" height="64" class="ap-bud">
                        <path d="M40 8 C50 22 52 38 40 56 C28 38 30 22 40 8 Z" fill="{{ $GOLD }}"
                            opacity=".9" />
                        <path d="M40 56 C26 52 14 40 12 26 C26 28 36 38 40 56 Z" fill="none"
                            stroke="{{ $GOLD }}" stroke-width="1.5" />
                        <path d="M40 56 C54 52 66 40 68 26 C54 28 44 38 40 56 Z" fill="none"
                            stroke="{{ $GOLD }}" stroke-width="1.5" />
                        <path d="M40 56 C20 58 8 52 2 42 C16 40 30 46 40 56 Z" fill="none"
                            stroke="{{ $GOLD }}" stroke-width="1.2" opacity=".7" />
                        <path d="M40 56 C60 58 72 52 78 42 C64 40 50 46 40 56 Z" fill="none"
                            stroke="{{ $GOLD }}" stroke-width="1.2" opacity=".7" />
                        <path d="M32 66 H48 M36 72 H44" stroke="{{ $GOLD }}" stroke-width="1.4"
                            stroke-linecap="round" />
                    </svg>
                    <div class="ap-divider" aria-hidden="true"><span></span><b></b><span></span></div>
                    @foreach ($lines as $i => $t)
                        <p class="ap-line" style="--i:{{ $i }}">{{ $t }}</p>
                    @endforeach
                    <div class="ap-divider" aria-hidden="true"><span></span><b></b><span></span></div>
                </div>
            </div>
        </div>
    </div>
</section>
