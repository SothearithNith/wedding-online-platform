<style>
        /* =====================================================================
           BASE
           ===================================================================== */
        *,
        *::before,
        *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html {
            -webkit-text-size-adjust: 100%;
            scroll-behavior: smooth;
        }

        body {
            background: #e9e2d0;
            font-family: 'Battambang', 'Noto Serif Khmer', serif;
            color: #2b2a2e;
            line-height: 1.8;
        }

        img {
            max-width: 100%;
        }

        button {
            font-family: inherit;
        }

        [hidden] {
            display: none !important;
        }

        .gw,
        .gc {
            --bg: #fbfaf6;
            --surface: #fff;
            --fg: #2b2a2e;
            --primary: #9a7418;
            --accent: #6c6f76;
            --foil: linear-gradient(125deg, #8a6414 0%, #d9b44a 22%, #fff0b7 42%, #c19a2e 65%, #8a6414 100%);
            --gold-light: #f6e3a0;
            --gold-dark: #8a6414;
            --hero-accent: #e3bd5a;
            --chakra: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 48 48' width='48' height='48'%3E%3Cpath d='M24 0L48 24L24 48L0 24Z' fill='none' stroke='black' stroke-width='1.4'/%3E%3Cpath d='M24 9L39 24L24 39L9 24Z' fill='none' stroke='black' stroke-width='1.4'/%3E%3Cpath d='M24 18L30 24L24 30L18 24Z'/%3E%3C/svg%3E");
            --band: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 28 14' width='28' height='14'%3E%3Cpath d='M14 1L26 7L14 13L2 7Z' fill='none' stroke='black' stroke-width='1.2'/%3E%3Cpath d='M14 4.5L19 7L14 9.5L9 7Z'/%3E%3C/svg%3E");
        }

        .gw {
            max-width: 448px;
            margin: 0 auto;
            overflow: hidden;
            background: #fbf6ea;
            color: #262626;
            box-shadow: 0 0 40px rgba(0, 0, 0, .18);
        }

        .font-display {
            font-family: 'Moul', 'Noto Serif Khmer', serif;
            font-weight: 400;
        }

        .font-khmer {
            font-family: 'Noto Sans Khmer', 'Battambang', sans-serif;
            line-height: 1.9;
        }

        .tnum {
            font-variant-numeric: tabular-nums;
        }

        .g-foil {
            display: inline-block;
            padding-block: .15em;
            background: var(--foil);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            filter: drop-shadow(0 2px 5px rgb(0 0 0 / 25%));
        }

        .g-foil-line {
            height: 1.5px;
            background: var(--foil);
            box-shadow: 0 0 12px rgb(217 180 74 / 35%);
        }

        .g-foil-box {
            border: 1.5px solid #d9b44a;
            box-shadow: inset 0 0 12px rgb(217 180 74 / 10%), 0 0 10px rgb(217 180 74 / 10%);
        }

        .g-spin {
            animation: g-spin 26s linear infinite;
            filter: drop-shadow(0 0 5px rgba(227, 189, 90, .6));
        }

        @keyframes g-spin {
            to {
                transform: rotate(360deg);
            }
        }

        /* =====================================================================
           SCROLL REVEAL  (class "in" is added by JS)
           ===================================================================== */
        .rv {
            opacity: 0;
            transition: opacity .9s cubic-bezier(.2, .8, .2, 1) var(--d, 0ms), transform 1s cubic-bezier(.2, .8, .2, 1) var(--d, 0ms), filter .9s ease var(--d, 0ms);
        }

        .rv[data-v="rise"] {
            transform: translateY(36px) scale(.96);
        }

        .rv:not([data-v]) {
            transform: translateY(22px);
        }

        .rv[data-v="blur"] {
            transform: translateY(14px);
            filter: blur(6px);
        }

        .rv[data-v="zoom"] {
            transform: scale(.88);
        }

        .rv[data-v="left"] {
            transform: translateX(-34px);
        }

        .rv[data-v="right"] {
            transform: translateX(34px);
        }

        .rv[data-v="unfold"] {
            transform: scaleX(.4);
        }

        .rv.in {
            opacity: 1;
            transform: none;
            filter: none;
        }

        html:not(.js) .rv,
        html:not(.js) .st-title,
        html:not(.js) .st-orn,
        html:not(.js) .kx-slide,
        html:not(.js) .kx-text,
        html:not(.js) .kg-tile,
        html:not(.js) .ap-line,
        html:not(.js) .ap-card-w,
        html:not(.js) .kx-heart-wrap {
            opacity: 1 !important;
            transform: none !important;
            filter: none !important;
        }

        /* =====================================================================
           SECTION SHELL
           ===================================================================== */
        .g-sec {
            position: relative;
            isolation: isolate;
            overflow: hidden;
        }

        .g-paper {
            background: var(--surface);
            color: var(--fg);
        }

        .g-photo {
            background: linear-gradient(180deg, #5b5e65 0%, #2c2d31 100%);
            color: #fff;
        }

        .g-bgimg {
            position: absolute;
            inset: 0;
            z-index: -2;
            background-size: cover;
            background-position: center;
            opacity: 0;
            transition: opacity 1s;
        }

        .g-bgimg.on {
            opacity: var(--bo, 1);
        }

        .g-ov {
            position: absolute;
            inset: 0;
            z-index: -1;
        }

        .g-chakra {
            position: absolute;
            inset: 0;
            z-index: -1;
            opacity: .07;
            background: var(--primary);
            -webkit-mask-image: var(--chakra);
            mask-image: var(--chakra);
            -webkit-mask-size: 48px 48px;
            mask-size: 48px 48px;
        }

        .g-in {
            position: relative;
        }

        .g-edge {
            position: absolute;
            left: 0;
            right: 0;
            height: 14px;
            z-index: 3;
            pointer-events: none;
        }

        .g-edge.top {
            top: -1px;
            background: radial-gradient(circle at 50% 0, var(--ec) 8px, transparent 8.5px) 0 0/20px 14px repeat-x;
        }

        .g-edge.bottom {
            bottom: -1px;
            background: radial-gradient(circle at 50% 100%, var(--ec) 8px, transparent 8.5px) 0 0/20px 14px repeat-x;
        }

        .g-arch-glass {
            position: relative;
            overflow: hidden;
            border-radius: 3rem;
            border: 1px solid rgba(246, 227, 160, .5);
            color: #fff;
            padding: 40px 24px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, .35), inset 0 1px 0 rgba(255, 241, 184, .45);
            background: rgba(27, 18, 9, .3);
            -webkit-backdrop-filter: blur(3px);
            backdrop-filter: blur(3px);
        }

        .g-arch-glass .gloss {
            position: absolute;
            left: 0;
            right: 0;
            top: 0;
            height: 25%;
            background: linear-gradient(to bottom, rgba(255, 255, 255, .2), transparent);
            pointer-events: none;
        }

        .ts {
            text-shadow: 0 1px 6px rgba(0, 0, 0, .85);
        }

        .ts-none {
            text-shadow: none;
        }

        .btn-foil {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            border: 0;
            cursor: pointer;
            background: var(--foil);
            color: #392708;
            font-weight: 600;
            text-decoration: none;
            transition: filter .2s, transform .2s;
            text-shadow: none;
        }

        .btn-foil:hover {
            filter: brightness(1.1);
        }

        .btn-foil:active {
            transform: scale(.95);
        }

        /* =====================================================================
           SECTION TITLE
           ===================================================================== */
        .st-wrap {
            margin-bottom: 2.2rem;
            text-align: center;
        }

        .st-title {
            margin: 0;
            font-size: clamp(1.7rem, 6.5vw, 2.4rem);
            font-weight: 400;
            line-height: 1.6;
            opacity: 0;
            transform: translateY(18px);
            filter: blur(8px);
            transition: opacity .9s cubic-bezier(.2, .8, .2, 1), transform 1s cubic-bezier(.2, .8, .2, 1), filter .9s ease;
        }

        .st-light .st-title {
            color: #f6e3a1;
            text-shadow: 0 1px 0 rgba(90, 50, 0, .6), 0 0 18px rgba(227, 189, 90, .65), 0 3px 14px rgba(0, 0, 0, .55);
        }

        .st-dark .st-title {
            color: #7a1f2b;
            text-shadow: 0 1px 0 rgba(255, 255, 255, .7), 0 2px 14px rgba(227, 189, 90, .55);
        }

        .st-wrap.in .st-title {
            opacity: 1;
            transform: none;
            filter: none;
        }

        .st-orn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            margin-top: .3rem;
            opacity: 0;
            transform: scaleX(.4);
            transition: opacity .9s ease .35s, transform 1.1s cubic-bezier(.2, .8, .2, 1) .35s;
        }

        .st-wrap.in .st-orn {
            opacity: 1;
            transform: none;
        }

        .st-orn span {
            flex: 1;
            max-width: 84px;
            height: 1px;
        }

        .st-orn span:first-child {
            background: linear-gradient(90deg, transparent, #e3bd5a);
        }

        .st-orn span:last-child {
            background: linear-gradient(270deg, transparent, #e3bd5a);
        }

        /* =====================================================================
           COVER (golden doors + open button)
           ===================================================================== */
        .gc {
            position: fixed;
            inset: 0;
            z-index: 80;
            overflow: hidden;
        }

        .gc.opened {
            pointer-events: none;
        }

        .gc-door {
            position: absolute;
            top: 0;
            bottom: 0;
            z-index: 20;
            width: 50%;
            overflow: hidden;
            background: linear-gradient(90deg, #5f410d, #b58a31 12%, #f4df9a 48%, #a77b20 85%, #51370d);
            box-shadow: inset 0 0 35px rgb(46 26 5 / 45%), 0 0 30px rgb(0 0 0 / 30%);
            transition: transform 1.8s cubic-bezier(.76, 0, .24, 1);
        }

        .gc-door.l {
            left: 0;
        }

        .gc-door.r {
            right: 0;
        }

        .gc.slide .gc-door.l {
            transform: translateX(-100%);
        }

        .gc.slide .gc-door.r {
            transform: translateX(100%);
        }

        .gc-door .pat {
            position: absolute;
            inset: 0;
            opacity: .2;
            background: #fff;
            -webkit-mask-image: var(--chakra);
            mask-image: var(--chakra);
            -webkit-mask-size: 44px 44px;
            mask-size: 44px 44px;
        }

        .gc-door .frame {
            position: absolute;
            inset: 12px;
            border: 1px solid rgb(255 235 177 / 55%);
            box-shadow: inset 0 0 20px rgb(255 230 160 / 15%), 0 0 10px rgb(0 0 0 / 15%);
        }

        .gc-door .cart {
            position: absolute;
            inset: 0;
            display: grid;
            place-items: center;
        }

        .gc-door .cart svg {
            height: min(62vh, 22rem);
            width: auto;
            aspect-ratio: 1/2;
            overflow: visible;
        }

        .gc-door .mirror svg {
            transform: scaleX(-1);
        }

        .gc-door .bar {
            position: absolute;
            top: 50%;
            width: 6px;
            height: 112px;
            transform: translateY(-50%);
            border-radius: 99px;
            background: var(--foil);
            box-shadow: 0 6px 12px rgba(0, 0, 0, .35);
        }

        .gc-door.l .bar {
            right: 24px;
        }

        .gc-door.r .bar {
            left: 24px;
        }

        .gc-door .knob {
            position: absolute;
            top: 50%;
            width: 12px;
            height: 12px;
            transform: translateY(-50%);
            border-radius: 50%;
            border: 1px solid #f6e3a0;
            background: var(--gold-dark);
        }

        .gc-door.l .knob {
            right: 22px;
        }

        .gc-door.r .knob {
            left: 22px;
        }

        .gc-main {
            position: absolute;
            inset: 0;
            z-index: 30;
            overflow: hidden;
            background: #160f09;
            transition: all 1s ease-in-out;
        }

        .gc.opened .gc-main {
            opacity: 0;
            transform: scale(1.04);
            pointer-events: none;
        }

        .gc-img {
            position: absolute;
            inset: 0;
            background: center top/cover no-repeat;
            animation: gold-cover-zoom 18s ease-in-out infinite alternate;
        }

        @keyframes gold-cover-zoom {
            to {
                transform: scale(1.09);
            }
        }

        .gc-shade {
            position: absolute;
            inset: 0;
            background: linear-gradient(to bottom, rgba(22, 15, 9, .75), rgba(37, 24, 12, .15), rgba(22, 15, 9, .85));
        }

        .gc-glow {
            position: absolute;
            inset: 0;
            pointer-events: none;
            background: radial-gradient(ellipse at 50% 35%, rgb(237 194 91 / 14%), transparent 55%), linear-gradient(120deg, transparent 20%, rgb(245 215 147 / 8%) 50%, transparent 80%);
        }

        .gc-box {
            position: absolute;
            inset: 14px;
            pointer-events: none;
        }

        .gc-corner {
            position: absolute;
            inset: 28px;
            border: 1px solid rgb(230 195 105 / 65%);
            pointer-events: none;
        }

        .gc-corner::before,
        .gc-corner::after {
            content: "❧";
            position: absolute;
            color: #f0d58c;
            font-size: 32px;
            line-height: 1;
            text-shadow: 0 0 12px rgb(217 180 74 / 40%);
        }

        .gc-corner::before {
            top: -15px;
            left: -10px;
            transform: rotate(-45deg);
        }

        .gc-corner::after {
            right: -10px;
            bottom: -15px;
            transform: rotate(135deg);
        }

        .g-particle {
            position: absolute;
            width: 4px;
            height: 4px;
            border-radius: 50%;
            background: #ffe8a0;
            box-shadow: 0 0 9px 2px rgb(255 218 125 / 65%);
            animation: gold-particle 5s ease-in-out infinite;
            animation-delay: var(--d);
        }

        @keyframes gold-particle {

            0%,
            100% {
                opacity: .15;
                transform: translate3d(0, 0, 0) scale(.7);
            }

            50% {
                opacity: 1;
                transform: translate3d(var(--x), -25px, 0) scale(1.4);
            }
        }

        .g-lotusfl {
            position: absolute;
            color: #f5d88c;
            opacity: .35;
            font-size: clamp(2rem, 6vw, 4rem);
            text-shadow: 0 0 20px rgb(255 222 145 / 40%);
            pointer-events: none;
            animation: lotus-float 6s ease-in-out infinite;
        }

        .g-lotusfl.a {
            left: 7%;
            top: 43%;
        }

        .g-lotusfl.b {
            right: 7%;
            top: 48%;
            animation-delay: -3s;
        }

        @keyframes lotus-float {

            0%,
            100% {
                transform: translateY(0) rotate(-8deg);
            }

            50% {
                transform: translateY(-16px) rotate(8deg);
            }
        }

        .g-reveal {
            opacity: 0;
            animation: khmer-reveal 1s cubic-bezier(.2, .7, .2, 1) both;
            animation-delay: var(--d, 0ms);
        }

        @keyframes khmer-reveal {
            from {
                opacity: 0;
                transform: translateY(22px);
                filter: blur(5px);
            }

            to {
                opacity: 1;
                transform: none;
                filter: blur(0);
            }
        }

        .gc-top {
            position: absolute;
            left: 0;
            right: 0;
            top: 12%;
            padding: 0 24px;
            text-align: center;
        }

        .gc-bot {
            position: absolute;
            left: 0;
            right: 0;
            bottom: 0;
            padding: 0 28px max(2.5rem, env(safe-area-inset-bottom));
            text-align: center;
            color: #fff;
        }

        .gc-guest {
            position: relative;
            max-width: 20rem;
            margin: 16px auto 0;
            padding: 12px 20px;
            border: 1px solid rgb(217 180 74 / 80%);
            background: rgb(255 251 235 / 95%);
            color: #594116;
            box-shadow: 0 8px 25px rgb(0 0 0 / 20%), inset 0 0 12px rgb(217 180 74 / 12%);
        }

        .gc-guest::before,
        .gc-guest::after {
            content: "✦";
            position: absolute;
            top: 50%;
            color: #b18a37;
            transform: translateY(-50%);
        }

        .gc-guest::before {
            left: 12px;
        }

        .gc-guest::after {
            right: 12px;
        }

        .gc-open {
            position: relative;
            overflow: hidden;
            display: inline-flex;
            align-items: center;
            gap: 12px;
            min-height: 56px;
            margin-top: 28px;
            padding: 0 36px;
            border-radius: 999px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            color: #392708;
            border: 1px solid rgb(255 255 255 / 70%);
            background: var(--foil);
            box-shadow: 0 8px 25px rgb(0 0 0 / 30%), inset 0 1px 3px rgb(255 255 255 / 70%);
            transition: transform .3s;
        }

        .gc-open:hover {
            transform: scale(1.05);
        }

        .gc-open:active {
            transform: scale(.95);
        }

        .gc-open::after {
            content: "";
            position: absolute;
            inset: 0;
            background: linear-gradient(110deg, transparent 25%, rgb(255 255 255 / 65%) 50%, transparent 75%);
            transform: translateX(-120%);
            animation: gold-button-shine 4s ease-in-out infinite;
        }

        @keyframes gold-button-shine {

            0%,
            65% {
                transform: translateX(-120%);
            }

            100% {
                transform: translateX(120%);
            }
        }

        /* =====================================================================
           HERO CARD
           ===================================================================== */
        .g-hero {
            position: relative;
            isolation: isolate;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            min-height: 100vh;
            min-height: 100svh;
            overflow: hidden;
            padding: 8px;
            background: #3a0810 center/cover no-repeat;
        }

        .kc-frame {
            position: relative;
            z-index: 10;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            width: 100%;
            max-width: 420px;
            padding: 24px 16px;
            text-align: center;
            color: #fbeec1;
            font-family: 'Battambang', 'Noto Serif Khmer', serif;
        }

        .kc-frame .kc-moul {
            font-family: 'Moul', 'Noto Serif Khmer', serif;
            font-weight: 400;
        }

        .kc-fx {
            position: absolute;
            inset: 0;
            z-index: 1;
            overflow: hidden;
            pointer-events: none;
        }

        .kc-fx .royal-glow {
            position: absolute;
            left: 50%;
            top: 50%;
            width: 75vw;
            height: 75vw;
            max-width: 600px;
            max-height: 600px;
            transform: translate(-50%, -50%);
            border-radius: 50%;
        }

        .royal-particle {
            position: absolute;
            border-radius: 50%;
            background: #e3bd5a;
            opacity: 0;
            box-shadow: 0 0 8px rgba(212, 175, 55, .7);
            animation: royal-particle 5s ease-in-out infinite;
        }

        .kc-shape {
            position: absolute;
            left: 50%;
            top: 50%;
            z-index: 0;
            pointer-events: none;
            width: 132%;
            height: 114%;
            translate: -50% -50%;
            background: radial-gradient(ellipse 50% 46% at 50% 52%, rgba(40, 6, 12, .74) 0%, rgba(40, 6, 12, .6) 45%, rgba(40, 6, 12, .25) 72%, transparent 100%);
            filter: blur(14px);
        }

        .kc-rays {
            position: absolute;
            left: 50%;
            top: 0;
            z-index: 0;
            pointer-events: none;
            width: 150%;
            max-width: 640px;
            aspect-ratio: 1;
            translate: -50% -34%;
            background: repeating-conic-gradient(from 0deg, rgba(255, 226, 140, .34) 0 3deg, transparent 3deg 12deg);
            -webkit-mask-image: radial-gradient(circle, #000 0%, rgba(0, 0, 0, .5) 34%, transparent 62%);
            mask-image: radial-gradient(circle, #000 0%, rgba(0, 0, 0, .5) 34%, transparent 62%);
            animation: kc-spin 70s linear infinite;
        }

        .kc-sun {
            position: absolute;
            left: 50%;
            top: 0;
            z-index: 0;
            pointer-events: none;
            width: 260px;
            height: 260px;
            translate: -50% -22%;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(255, 232, 150, .55) 0%, rgba(255, 200, 90, .22) 42%, transparent 70%);
            animation: kc-sunpulse 5s ease-in-out infinite alternate;
        }

        @keyframes kc-sunpulse {
            from {
                opacity: .65;
                transform: scale(.94);
            }

            to {
                opacity: 1;
                transform: scale(1.06);
            }
        }

        .kc-dust i {
            position: absolute;
            bottom: -10px;
            border-radius: 50%;
            opacity: 0;
            background: radial-gradient(circle, #fff3c4, #e3bd5a 60%, transparent 70%);
            animation: kc-rise linear infinite;
        }

        @keyframes kc-rise {
            0% {
                transform: translate(0, 0) scale(.6);
                opacity: 0;
            }

            15% {
                opacity: .9;
            }

            100% {
                transform: translate(var(--dx), -100vh) scale(1.2);
                opacity: 0;
            }
        }

        .kc-mandala {
            position: absolute;
            left: 50%;
            top: 50%;
            width: 150%;
            max-width: 760px;
            aspect-ratio: 1;
            translate: -50% -50%;
            opacity: .14;
            pointer-events: none;
            animation: kc-spin 90s linear infinite;
            z-index: 1;
        }

        @keyframes kc-spin {
            to {
                rotate: 360deg;
            }
        }

        .kc-angkor {
            display: block;
            width: min(160px, 44%);
            height: auto;
            margin: 0 auto;
            filter: drop-shadow(0 0 6px rgba(227, 189, 90, .5));
            animation: kc-glow 3.5s ease-in-out infinite, kc-float 6s ease-in-out infinite;
        }

        @keyframes kc-glow {
            50% {
                filter: drop-shadow(0 0 14px rgba(255, 226, 140, .95));
            }
        }

        @keyframes kc-float {
            50% {
                transform: translateY(-3px);
            }
        }

        .kc-angkor-base {
            width: min(150px, 42%);
            height: 1px;
            margin: 2px auto 0;
            background: linear-gradient(90deg, transparent, #e3bd5a, transparent);
            box-shadow: 0 0 10px 1px rgba(227, 189, 90, .55);
        }

        .kc-name {
            background: var(--foil);
            background-size: 220% 100%;
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            animation: kc-foil 6s linear infinite;
            font-size: .95rem;
            line-height: 1.9;
            filter: drop-shadow(0 2px 8px rgba(0, 0, 0, .45));
        }

        @keyframes kc-foil {
            to {
                background-position: 220% 0;
            }
        }

        .kc-knot {
            animation: kc-spin2 18s linear infinite;
            filter: drop-shadow(0 0 6px rgba(227, 189, 90, .6));
        }

        @keyframes kc-spin2 {
            to {
                transform: rotate(360deg);
            }
        }

        .kc-date {
            position: relative;
            display: inline-block;
            padding: .45rem 1.3rem;
            border-radius: 999px;
            border: 1px solid #e3bd5a;
            background: rgba(227, 189, 90, .12);
            overflow: hidden;
            letter-spacing: .04em;
            font-size: 12px;
            color: #fbeec1;
        }

        .kc-date::after {
            content: "";
            position: absolute;
            inset: 0;
            pointer-events: none;
            background: linear-gradient(115deg, transparent 38%, rgba(255, 240, 180, .45) 50%, transparent 62%);
            transform: translateX(-130%);
            animation: kc-shine 5.5s ease-in-out infinite 2s;
        }

        @keyframes kc-shine {

            0%,
            55% {
                transform: translateX(-130%);
            }

            100% {
                transform: translateX(130%);
            }
        }

        .kc-kanok {
            display: block;
            opacity: .85;
            -webkit-mask-image: linear-gradient(90deg, transparent, #000 12%, #000 88%, transparent);
            mask-image: linear-gradient(90deg, transparent, #000 12%, #000 88%, transparent);
        }

        .kc-scroll {
            position: absolute;
            left: 50%;
            bottom: 14px;
            translate: -50% 0;
            z-index: 20;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 2px;
            pointer-events: none;
            color: #e3bd5a;
            font-size: 10px;
            letter-spacing: .2em;
            opacity: 0;
            animation: kc-in 1s ease 3s forwards;
        }

        .kc-scroll svg {
            animation: kc-bounce 1.8s ease-in-out infinite;
        }

        @keyframes kc-in {
            to {
                opacity: .85;
            }
        }

        @keyframes kc-bounce {
            50% {
                transform: translateY(6px);
            }
        }

        .royal-enter {
            opacity: 0;
            animation: royal-enter 1s cubic-bezier(.2, .7, .2, 1) forwards;
            animation-delay: var(--d, 0ms);
        }

        .royal-logo {
            animation: royal-logo-reveal 1.8s ease-out both;
            animation-delay: 1s;
            filter: drop-shadow(0 2px 8px rgba(180, 135, 30, .18));
        }

        .royal-shimmer {
            display: inline-block;
            color: #c49a36;
            animation: royal-shimmer 3s ease-in-out infinite;
        }

        .royal-diamond {
            animation: royal-diamond 5s ease-in-out infinite;
        }

        .royal-ornament-glow {
            animation: royal-ornament 5s ease-in-out infinite alternate;
        }

        .royal-emblem-glow {
            animation: royal-emblem 5s ease-in-out infinite alternate;
        }

        .royal-quote {
            color: #b28a38;
            font-style: italic;
        }

        .royal-bottom-ornament {
            color: #bd9135;
            animation: royal-bottom 4s ease-in-out infinite;
        }

        @keyframes royal-enter {
            from {
                opacity: 0;
                transform: translateY(15px);
                filter: blur(5px);
            }

            to {
                opacity: 1;
                transform: none;
                filter: blur(0);
            }
        }

        @keyframes royal-logo-reveal {
            from {
                opacity: 0;
                transform: scale(.92);
                filter: blur(5px);
            }

            to {
                opacity: 1;
                transform: scale(1);
                filter: drop-shadow(0 2px 8px rgba(180, 135, 30, .18));
            }
        }

        @keyframes royal-shimmer {

            0%,
            100% {
                opacity: .55;
                transform: scale(1);
            }

            50% {
                opacity: 1;
                transform: scale(1.12);
                filter: drop-shadow(0 0 5px rgba(212, 175, 55, .65));
            }
        }

        @keyframes royal-diamond {

            0%,
            100% {
                transform: rotate(0);
            }

            50% {
                transform: rotate(45deg);
            }
        }

        @keyframes royal-ornament {
            from {
                filter: drop-shadow(0 0 2px rgba(212, 175, 55, .15));
            }

            to {
                filter: drop-shadow(0 0 9px rgba(212, 175, 55, .45));
            }
        }

        @keyframes royal-glow {
            from {
                opacity: .55;
                transform: translate(-50%, -50%) scale(.9);
            }

            to {
                opacity: 1;
                transform: translate(-50%, -50%) scale(1.12);
            }
        }

        .kc-fx .royal-glow {
            background: radial-gradient(circle, rgba(212, 175, 55, .12) 0%, rgba(212, 175, 55, .04) 45%, transparent 72%);
            animation: royal-glow 7s ease-in-out infinite alternate;
        }

        @keyframes royal-particle {
            0% {
                opacity: 0;
                transform: translateY(12px) scale(.5);
            }

            30% {
                opacity: .65;
            }

            70% {
                opacity: .35;
            }

            100% {
                opacity: 0;
                transform: translateY(-30px) scale(1.2);
            }
        }

        @keyframes royal-emblem {
            from {
                filter: drop-shadow(0 0 2px rgba(212, 175, 55, .1));
                transform: scale(.98);
            }

            to {
                filter: drop-shadow(0 0 12px rgba(212, 175, 55, .3));
                transform: scale(1.04);
            }
        }

        @keyframes royal-bottom {

            0%,
            100% {
                opacity: .65;
                letter-spacing: .4em;
            }

            50% {
                opacity: 1;
                letter-spacing: .55em;
            }
        }

        .hl-label {
            font-size: 10px;
            letter-spacing: .17em;
            color: rgba(227, 189, 90, .85);
        }

        .hl-rule {
            height: 1px;
            background: rgba(227, 189, 90, .4);
        }

        .hl-parent {
            font-size: 12px;
            line-height: 1.6;
            color: #fbeec1;
        }

        .chakra-band {
            height: 14px;
            background: var(--foil);
            -webkit-mask-image: var(--band);
            mask-image: var(--band);
            -webkit-mask-repeat: repeat-x;
            mask-repeat: repeat-x;
            -webkit-mask-size: 28px 14px;
            mask-size: 28px 14px;
            margin: 0 auto;
        }

        /* =====================================================================
           COUPLE (animated arch frames)
           ===================================================================== */
        .cp-wrap {
            position: relative;
            z-index: 1;
            display: flex;
            align-items: center;
            max-width: 24rem;
            min-height: calc(100svh - 11rem);
            margin: 0 auto;
        }

        .cp-in {
            position: relative;
            width: 100%;
        }

        .cp-halo {
            position: absolute;
            left: 50%;
            top: 50%;
            z-index: -1;
            width: 150%;
            aspect-ratio: 1;
            transform: translate(-50%, -50%);
            pointer-events: none;
            -webkit-mask-image: radial-gradient(circle, #000 15%, transparent 65%);
            mask-image: radial-gradient(circle, #000 15%, transparent 65%);
        }

        .cp-halo div {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            opacity: .5;
            background: repeating-conic-gradient(from 0deg, rgba(246, 227, 160, .6) 0deg 4deg, transparent 4deg 14deg);
            animation: g-spin 30s linear infinite;
        }

        .cp-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
        }

        .cp-grid>div:last-child {
            margin-top: 22vh;
            margin-top: 22svh;
        }

        .kx-slide {
            opacity: 0;
        }

        .kx-on .kx-slide-l {
            animation: kx-in-l 1.3s cubic-bezier(.2, .8, .2, 1) both;
            animation-delay: var(--dl);
        }

        .kx-on .kx-slide-r {
            animation: kx-in-r 1.3s cubic-bezier(.2, .8, .2, 1) both;
            animation-delay: var(--dl);
        }

        @keyframes kx-in-l {
            from {
                opacity: 0;
                transform: translateX(-70px) rotate(-3deg);
            }

            to {
                opacity: 1;
                transform: none;
            }
        }

        @keyframes kx-in-r {
            from {
                opacity: 0;
                transform: translateX(70px) rotate(3deg);
            }

            to {
                opacity: 1;
                transform: none;
            }
        }

        .kx-fwrap {
            position: relative;
            margin: 0 auto;
            width: min(100%, 25vh);
            width: min(100%, 25svh);
        }

        .kx-fglow {
            position: absolute;
            left: 12px;
            right: 12px;
            top: 32px;
            bottom: 32px;
            border-radius: 999px;
            opacity: .4;
            filter: blur(40px);
            background: radial-gradient(circle, #f0d58a, transparent 70%);
        }

        .kx-fsvg {
            position: relative;
            display: block;
            width: 100%;
            overflow: visible;
        }

        .kx-float {
            animation: kx-float 5s ease-in-out infinite alternate;
            filter: drop-shadow(0 12px 16px rgba(0, 0, 0, .55));
        }

        .kx-float-b {
            animation: kx-float 6.5s ease-in-out infinite alternate-reverse;
            filter: drop-shadow(0 12px 16px rgba(0, 0, 0, .55));
        }

        @keyframes kx-float {
            from {
                transform: translateY(0);
            }

            to {
                transform: translateY(-9px);
            }
        }

        .kx-outline {
            stroke-dasharray: 1000;
        }

        .kx-on .kx-outline {
            animation: kx-draw 2.2s ease-out both;
            animation-delay: var(--dl);
        }

        @keyframes kx-draw {
            from {
                stroke-dashoffset: 1000;
            }

            to {
                stroke-dashoffset: 0;
            }
        }

        .kx-photo {
            transform-box: view-box;
            transform-origin: 150px 210px;
        }

        .kx-on .kx-photo {
            animation: kx-photo 1.8s ease-out both;
            animation-delay: calc(var(--dl) + 900ms);
        }

        @keyframes kx-photo {
            from {
                opacity: 0;
                transform: scale(1.3);
            }

            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        .kx-sweep {
            animation: kx-sweep 5.5s ease-in-out infinite;
            animation-delay: calc(var(--dl) + 2.5s);
        }

        @keyframes kx-sweep {
            0% {
                transform: translateX(-420px) skewX(-18deg);
            }

            40%,
            100% {
                transform: translateX(520px) skewX(-18deg);
            }
        }

        .kx-flame {
            transform-box: fill-box;
            transform-origin: 50% 100%;
            animation: kx-flame 2.6s ease-in-out infinite;
        }

        @keyframes kx-flame {

            0%,
            100% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.18);
            }
        }

        .kx-text {
            opacity: 0;
            margin-top: 8px;
            text-align: center;
        }

        .kx-on .kx-text {
            animation: kx-text 1s ease-out both;
            animation-delay: calc(var(--dl) + 1500ms);
        }

        @keyframes kx-text {
            from {
                opacity: 0;
                transform: translateY(14px);
            }

            to {
                opacity: 1;
                transform: none;
            }
        }

        .kx-name {
            font-size: 1rem;
            font-weight: 700;
            line-height: 1.8;
            background: linear-gradient(100deg, #a87c2e 10%, #fff1b8 30%, #f0d58a 50%, #fff1b8 70%, #a87c2e 90%);
            background-size: 200% 100%;
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            animation: kx-name 5s linear infinite;
        }

        @keyframes kx-name {
            100% {
                background-position: 200% 50%;
            }
        }

        .kx-divider {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            width: 7rem;
            margin: 4px auto 0;
        }

        .kx-divline {
            flex: 1;
            height: 1px;
            transform: scaleX(0);
        }

        .kx-on .kx-divline {
            animation: kx-line 1.2s ease-out both;
            animation-delay: calc(var(--dl) + 1700ms);
        }

        @keyframes kx-line {
            to {
                transform: scaleX(1);
            }
        }

        .kx-dia {
            display: block;
            width: 6px;
            height: 6px;
            background: #f0d58a;
            animation: kx-dia 2.4s ease-in-out infinite;
        }

        @keyframes kx-dia {

            0%,
            100% {
                transform: rotate(45deg) scale(1);
            }

            50% {
                transform: rotate(45deg) scale(1.35);
            }
        }

        .kx-heartpos {
            position: absolute;
            left: 50%;
            top: 46%;
            z-index: 20;
            transform: translate(-50%, -50%);
            pointer-events: none;
        }

        .kx-heart-wrap {
            position: relative;
            display: grid;
            place-items: center;
            width: 4.5rem;
            height: 4.5rem;
            opacity: 0;
        }

        .kx-on .kx-heart-wrap {
            animation: kx-pop 1.2s cubic-bezier(.2, .9, .3, 1.3) both;
            animation-delay: 1.5s;
        }

        @keyframes kx-pop {
            from {
                opacity: 0;
                transform: scale(.2) rotate(-120deg);
            }

            to {
                opacity: 1;
                transform: none;
            }
        }

        .kx-heart {
            transform-origin: 50% 55%;
            animation: kx-beat 1.8s ease-in-out infinite;
        }

        @keyframes kx-beat {

            0%,
            100% {
                transform: scale(1);
            }

            15% {
                transform: scale(1.22);
            }

            30% {
                transform: scale(1);
            }

            45% {
                transform: scale(1.14);
            }

            60% {
                transform: scale(1);
            }
        }

        .kx-ringwave {
            position: absolute;
            inset: 12px;
            border-radius: 50%;
            border: 2px solid rgba(246, 227, 160, .7);
            animation: kx-ring 2.4s ease-out infinite;
        }

        .kx-ringwave.b {
            border: 1px solid rgba(255, 143, 163, .6);
            animation-delay: 1.2s;
        }

        @keyframes kx-ring {
            from {
                transform: scale(.7);
                opacity: .7;
            }

            to {
                transform: scale(2.3);
                opacity: 0;
            }
        }

        .kx-orbit {
            transform-box: fill-box;
            transform-origin: center;
            animation: kx-spin 18s linear infinite;
        }

        @keyframes kx-spin {
            to {
                transform: rotate(360deg);
            }
        }

        .kx-hearts {
            position: absolute;
            inset: 0;
            overflow: hidden;
            pointer-events: none;
        }

        .kx-love {
            position: absolute;
            bottom: 0;
            font-size: 14px;
            color: #ff8fa3;
            opacity: 0;
            animation: kx-up 6s ease-in infinite;
        }

        @keyframes kx-up {
            0% {
                transform: translateY(0) scale(.6);
                opacity: 0;
            }

            20% {
                opacity: 1;
            }

            100% {
                transform: translateY(-150px) scale(1.1);
                opacity: 0;
            }
        }

        /* =====================================================================
           COUNTDOWN + ADD TO CALENDAR
           ===================================================================== */
        .cd-box {
            position: relative;
            max-width: 24rem;
            margin: 32px auto 0;
            padding: 28px 8px;
            background: var(--surface);
        }

        .cd-box::before {
            content: "";
            position: absolute;
            inset: 6px;
            border: 1px solid rgba(154, 116, 24, .4);
            pointer-events: none;
        }

        .cd-box .dm {
            position: absolute;
            width: 12px;
            height: 12px;
            transform: rotate(45deg);
            background: var(--foil);
        }

        .cd-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
        }

        .cd-grid>div+div {
            border-left: 1px solid rgba(154, 116, 24, .25);
        }

        .cd-grid .num {
            font-size: 1.875rem;
            font-weight: 600;
            line-height: 1.4;
        }

        .cd-grid .num.tick {
            animation: tick .5s ease;
        }

        @keyframes tick {
            from {
                transform: translateY(-60%);
                opacity: 0;
            }

            to {
                transform: none;
                opacity: 1;
            }
        }

        .ac-wrap {
            display: flex;
            justify-content: center;
            margin-top: 2rem;
        }

        .ac-btn {
            position: relative;
            display: inline-flex;
            align-items: center;
            gap: .6rem;
            min-height: 48px;
            padding: 0 1.8rem;
            border-radius: 999px;
            cursor: pointer;
            border: 1.5px solid #c9962b;
            background: rgba(255, 248, 230, .5);
            color: #7a4f08;
            font-weight: 600;
            font-size: .92rem;
            letter-spacing: .03em;
            overflow: visible;
            box-shadow: 0 6px 20px rgba(0, 0, 0, .15);
            transition: background .35s, color .35s, transform .2s, box-shadow .35s;
            animation: ac-pulse 3.2s ease-in-out infinite;
        }

        @keyframes ac-pulse {

            0%,
            100% {
                box-shadow: 0 6px 20px rgba(0, 0, 0, .15), 0 0 0 0 rgba(227, 189, 90, .45);
            }

            50% {
                box-shadow: 0 6px 20px rgba(0, 0, 0, .15), 0 0 0 10px rgba(227, 189, 90, 0);
            }
        }

        .ac-btn:hover,
        .ac-btn.done {
            background: var(--foil);
            color: #3b2503;
            animation: none;
        }

        .ac-btn:active {
            transform: scale(.94);
        }

        .ac-btn::after {
            content: "";
            position: absolute;
            inset: 0;
            border-radius: inherit;
            pointer-events: none;
            background: linear-gradient(115deg, transparent 38%, rgba(255, 240, 180, .5) 50%, transparent 62%);
            transform: translateX(-130%);
            animation: ac-shine 5s ease-in-out infinite 1s;
        }

        @keyframes ac-shine {

            0%,
            60% {
                transform: translateX(-130%);
            }

            100% {
                transform: translateX(130%);
            }
        }

        .burst-ring {
            position: absolute;
            inset: -2px;
            border-radius: 999px;
            border: 2px solid #e3bd5a;
            pointer-events: none;
            animation: burst-ring .9s ease-out forwards;
        }

        @keyframes burst-ring {
            from {
                opacity: .9;
                transform: scale(1);
            }

            to {
                opacity: 0;
                transform: scale(1.55);
            }
        }

        .burst-spark {
            position: absolute;
            left: 50%;
            top: 50%;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: #e3bd5a;
            pointer-events: none;
            animation: burst-spark .8s ease-out forwards;
        }

        @keyframes burst-spark {
            from {
                opacity: 1;
                transform: translate(-50%, -50%) rotate(var(--a)) translateY(0);
            }

            to {
                opacity: 0;
                transform: translate(-50%, -50%) rotate(var(--a)) translateY(-46px);
            }
        }

        /* =====================================================================
           STORY
           ===================================================================== */
        .tl {
            position: relative;
            margin-left: 8px;
            padding-left: 32px;
            list-style: none;
            text-align: left;
        }

        .tl-line {
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 1px;
            transform-origin: top;
            transform: scaleY(0);
            background: linear-gradient(to bottom, #f6e3a0, rgba(217, 182, 111, .7), transparent);
            transition: transform 2s ease-out;
        }

        .tl.seen .tl-line {
            transform: scaleY(1);
        }

        .tl li {
            position: relative;
            margin-bottom: 40px;
        }

        .tl li:last-child {
            margin-bottom: 0;
        }

        .tl .node {
            position: absolute;
            left: -46px;
            top: 0;
            display: grid;
            place-items: center;
            width: 28px;
            height: 28px;
            transform: rotate(45deg);
            background: linear-gradient(135deg, #f6e3a0, #b8862f);
            color: #392708;
            box-shadow: 0 6px 12px rgba(0, 0, 0, .4);
        }

        .tl .node svg {
            transform: rotate(-45deg);
            fill: currentColor;
        }

        .tl .yr {
            font-size: 14px;
            font-weight: 600;
            letter-spacing: .1em;
            color: #f6e3a0;
        }

        .tl h3 {
            margin-top: 8px;
            font-size: 14px;
            color: #fff;
        }

        .tl p {
            margin-top: 8px;
            font-size: 14px;
            line-height: 1.7;
            color: rgba(255, 255, 255, .9);
        }

        /* =====================================================================
           SCHEDULE
           ===================================================================== */
        .sc-date {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
            max-width: 17rem;
            margin: 24px auto 40px;
            text-align: center;
        }

        .sc-date .badge {
            position: relative;
            display: grid;
            place-items: center;
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: linear-gradient(135deg, #f6e3a0, #b8862f);
            color: #392708;
            box-shadow: 0 6px 14px rgba(0, 0, 0, .4);
        }

        .sc-date .badge::before {
            content: "";
            position: absolute;
            inset: -6px;
            border-radius: 50%;
            border: 1px solid rgba(246, 227, 160, .4);
        }

        .dia {
            display: block;
            width: 6px;
            height: 6px;
            transform: rotate(45deg);
            background: #f6e3a0;
        }

        .dl {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .dl .l1,
        .dl .l2 {
            height: 1px;
            width: 40px;
        }

        .dl .l1 {
            background: linear-gradient(to right, transparent, #f0d58a);
        }

        .dl .l2 {
            background: linear-gradient(to left, transparent, #f0d58a);
        }

        .ev-list {
            position: relative;
            margin-left: 16px;
            padding-left: 36px;
            list-style: none;
            text-align: left;
        }

        .ev-track,
        .ev-fill {
            position: absolute;
            left: 0;
            top: 8px;
            height: calc(100% - 1rem);
        }

        .ev-track {
            width: 1px;
            background: rgba(246, 227, 160, .15);
        }

        .ev-fill {
            width: 2px;
            margin-left: -1px;
            transform-origin: top;
            transform: scaleY(0);
            will-change: transform;
            background: linear-gradient(to bottom, #f6e3a0, #d9b66f, #b8862f);
            box-shadow: 0 0 10px rgba(246, 227, 160, .7);
        }

        .ev-list>li {
            position: relative;
            margin-bottom: 32px;
        }

        .ev-node {
            position: absolute;
            left: -3.25rem;
            top: 0;
            display: grid;
            place-items: center;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            border: 2px solid rgba(246, 227, 160, .4);
            background: #1b1209;
            color: rgba(246, 227, 160, .6);
            transition: all .5s;
        }

        .ev-list>li.reached .ev-node {
            border-color: #1b1209;
            background: linear-gradient(135deg, #f6e3a0, #b8862f);
            color: #392708;
            box-shadow: 0 6px 14px rgba(0, 0, 0, .5);
        }

        .ev-list>li.active .ev-node {
            transform: scale(1.1);
        }

        .ev-list>li.active .ev-node::after {
            content: "";
            position: absolute;
            inset: -6px;
            border-radius: 50%;
            border: 1px solid rgba(246, 227, 160, .7);
            animation: ping 1.4s cubic-bezier(0, 0, .2, 1) infinite;
        }

        @keyframes ping {

            75%,
            100% {
                transform: scale(1.8);
                opacity: 0;
            }
        }

        .ev-card {
            position: relative;
            overflow: hidden;
            padding: 16px 16px 16px 24px;
            border-radius: 16px;
            border: 1px solid rgba(246, 227, 160, .25);
            background: rgba(0, 0, 0, .25);
            transition: all .5s;
        }

        .ev-list>li.active .ev-card {
            border-color: rgba(246, 227, 160, .7);
            background: rgba(0, 0, 0, .4);
            box-shadow: 0 0 28px rgba(246, 227, 160, .22);
        }

        .ev-card .edge {
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 4px;
            background: linear-gradient(to bottom, #f6e3a0, #b8862f);
            opacity: .4;
            transition: opacity .5s;
        }

        .ev-list>li.active .ev-card .edge {
            opacity: 1;
        }

        .ev-time {
            font-size: 1.875rem;
            font-weight: 600;
            line-height: 1;
            color: #f6e3a0;
        }

        .ev-card h3 {
            margin-top: 12px;
            font-size: 16px;
            line-height: 1.5;
            color: #fff;
            font-weight: 700;
        }

        .ev-place {
            display: flex;
            align-items: flex-start;
            gap: 6px;
            margin-top: 6px;
            font-size: 14px;
            line-height: 1.5;
            color: rgba(255, 255, 255, .85);
            word-break: break-word;
        }

        .ev-place svg {
            margin-top: 3px;
            flex: none;
            color: #f6e3a0;
        }

        .ev-map {
            min-height: 40px;
            margin-top: 12px;
            padding: 0 16px;
            border-radius: 999px;
            font-size: 12px;
            box-shadow: 0 6px 14px rgba(0, 0, 0, .4);
        }

        .ev-end {
            position: relative;
            height: 24px;
            margin-top: -8px;
        }

        .ev-end span {
            position: absolute;
            left: -2.6rem;
            top: 0;
            display: grid;
            place-items: center;
            width: 24px;
            height: 24px;
            border-radius: 50%;
            border: 1px solid rgba(246, 227, 160, .3);
            color: rgba(246, 227, 160, .4);
            transition: all .7s;
        }

        .ev-end span svg {
            fill: currentColor;
        }

        .ev-end.on span {
            border-color: #f6e3a0;
            background: rgba(246, 227, 160, .15);
            color: #f6e3a0;
        }

        /* =====================================================================
           GALLERY (arch tiles + lightbox)
           ===================================================================== */
        .kg-section {
            position: relative;
            overflow: hidden;
            padding: 80px 20px 96px;
            background: #1a1410 center/cover;
        }

        .kg-overlay {
            position: absolute;
            inset: 0;
            background: linear-gradient(180deg, rgba(20, 8, 4, .55), rgba(20, 8, 4, .3) 40%, rgba(20, 8, 4, .6));
        }

        .kg-kanok {
            position: absolute;
            left: 0;
            right: 0;
            opacity: .85;
            pointer-events: none;
            z-index: 1;
        }

        .kg-kanok.top {
            top: 0;
        }

        .kg-kanok.bottom {
            bottom: 0;
        }

        .kg-dust {
            position: absolute;
            inset: 0;
            overflow: hidden;
            pointer-events: none;
            z-index: 1;
        }

        .kg-dust i {
            position: absolute;
            bottom: -12px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: radial-gradient(circle, #fff3c4, #e3bd5a 60%, transparent 70%);
            opacity: 0;
            animation: kc-rise linear infinite;
        }

        .kg-orn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 14px;
            margin: -6px 0 8px;
        }

        .kg-orn span {
            height: 1px;
            flex: 1;
            max-width: 90px;
            background: linear-gradient(90deg, transparent, #e3bd5a, transparent);
        }

        .kg-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 24px 16px;
            max-width: 48rem;
            margin: 0 auto;
        }

        .kg-tile {
            opacity: 0;
            transform: translateY(46px) rotate(var(--r, -2deg)) scale(.94);
            transition: opacity .9s cubic-bezier(.2, .8, .2, 1) var(--d), transform 1s cubic-bezier(.2, .8, .2, 1) var(--d);
        }

        .kg-tile.kg-odd {
            --r: 2deg;
            margin-top: 2rem;
        }

        .kg-tile.kg-in {
            opacity: 1;
            transform: none;
        }

        .kg-finial {
            display: block;
            margin: 0 auto -2px;
            filter: drop-shadow(0 0 5px rgba(227, 189, 90, .6));
            animation: kg-glow 3s ease-in-out infinite;
        }

        @keyframes kg-glow {
            50% {
                filter: drop-shadow(0 0 11px rgba(255, 226, 140, .95));
            }
        }

        .kg-frame {
            display: block;
            width: 100%;
            padding: 3px;
            cursor: pointer;
            border: 0;
            border-radius: 999px 999px 0 0;
            background: var(--foil);
            box-shadow: 0 10px 30px rgba(0, 0, 0, .45);
            animation: kg-bob 6s ease-in-out infinite;
            animation-delay: var(--d);
            transition: transform .5s, box-shadow .5s;
        }

        .kg-frame:hover {
            transform: translateY(-6px) scale(1.03);
            box-shadow: 0 18px 44px rgba(227, 189, 90, .35);
        }

        @keyframes kg-bob {
            50% {
                translate: 0 -6px;
            }
        }

        .kg-inner {
            position: relative;
            width: 100%;
            aspect-ratio: 3/4;
            overflow: hidden;
            border-radius: 999px 999px 0 0;
            background: #000;
        }

        .kg-inner img {
            position: absolute;
            inset: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            clip-path: inset(100% 0 0 0);
            transform: scale(1.25);
            transition: clip-path 1.3s cubic-bezier(.2, .8, .2, 1) calc(var(--d) + .25s), transform 1.8s cubic-bezier(.2, .8, .2, 1) calc(var(--d) + .25s);
        }

        .kg-in .kg-inner img {
            clip-path: inset(0);
            transform: scale(1);
        }

        .kg-frame:hover .kg-inner img {
            transform: scale(1.1);
        }

        .kg-inner::after {
            content: "";
            position: absolute;
            inset: 0;
            pointer-events: none;
            background: linear-gradient(115deg, transparent 35%, rgba(255, 240, 180, .55) 50%, transparent 65%);
            transform: translateX(-120%);
            animation: kg-shine 5.5s ease-in-out infinite;
            animation-delay: calc(var(--d) + 1.5s);
        }

        @keyframes kg-shine {

            0%,
            60% {
                transform: translateX(-120%);
            }

            100% {
                transform: translateX(120%);
            }
        }

        .kg-lb {
            position: fixed;
            inset: 0;
            z-index: 100;
            display: none;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 16px;
            background: rgba(0, 0, 0, .92);
            -webkit-backdrop-filter: blur(4px);
            backdrop-filter: blur(4px);
            animation: kg-fade .35s ease both;
        }

        .kg-lb.open {
            display: flex;
        }

        @keyframes kg-fade {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        .kg-lb-frame {
            position: relative;
            width: min(80vw, 28rem);
            height: 68vh;
            height: 68svh;
            padding: 4px;
            border-radius: 999px 999px 8px 8px;
            background: var(--foil);
            box-shadow: 0 0 60px rgba(227, 189, 90, .35);
            animation: kg-pop .6s cubic-bezier(.2, .9, .2, 1) both;
        }

        .kg-lb-frame img {
            display: block;
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 999px 999px 6px 6px;
            background: #000;
        }

        @keyframes kg-pop {
            from {
                opacity: 0;
                transform: scale(.8) translateY(30px);
            }

            to {
                opacity: 1;
                transform: none;
            }
        }

        .kg-thumbs {
            display: flex;
            align-items: flex-end;
            gap: 8px;
        }

        .kg-thumb {
            width: 44px;
            height: 58px;
            border-radius: 999px 999px 4px 4px;
            overflow: hidden;
            border: 2px solid transparent;
            opacity: .5;
            transition: .3s;
            cursor: pointer;
            padding: 0;
            background: #000;
        }

        .kg-thumb.on {
            border-color: #e3bd5a;
            opacity: 1;
            transform: translateY(-4px);
        }

        .kg-thumb img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .kg-count {
            font-size: 14px;
            letter-spacing: .1em;
            color: #e3bd5a;
        }

        .kg-circle {
            position: absolute;
            display: grid;
            place-items: center;
            width: 48px;
            height: 48px;
            border: 0;
            border-radius: 50%;
            cursor: pointer;
            background: rgba(255, 255, 255, .15);
            color: #fff;
            -webkit-backdrop-filter: blur(6px);
            backdrop-filter: blur(6px);
            transition: background .2s, transform .2s;
        }

        .kg-circle:hover {
            background: rgba(255, 255, 255, .3);
        }

        .kg-circle:active {
            transform: scale(.9);
        }

        .kg-circle.x {
            right: 12px;
            top: max(.75rem, env(safe-area-inset-top));
        }

        .kg-circle.p {
            left: 8px;
            top: 50%;
            margin-top: -24px;
        }

        .kg-circle.n {
            right: 8px;
            top: 50%;
            margin-top: -24px;
        }

        /* =====================================================================
           DRESS CODE
           ===================================================================== */
        .dc-colors {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 28px;
            margin-top: 40px;
        }

        .dc-sw {
            display: block;
            width: 48px;
            height: 48px;
            transform: rotate(45deg);
            border-radius: 2px;
            padding: 2px;
            background: var(--foil);
            box-shadow: 0 1px 2px rgba(0, 0, 0, .15);
        }

        .dc-sw span {
            display: block;
            width: 100%;
            height: 100%;
            border-radius: 2px;
        }

        /* =====================================================================
           RSVP
           ===================================================================== */
        .rs-sub {
            max-width: 16rem;
            margin: 0 auto 28px;
            text-align: center;
            font-size: 14px;
            line-height: 1.7;
            color: rgba(255, 255, 255, .9);
        }

        .rs-form {
            display: grid;
            gap: 16px;
            text-align: left;
        }

        .rs-field {
            width: 100%;
            border-radius: 16px;
            border: 1px solid rgba(246, 227, 160, .4);
            background: rgba(0, 0, 0, .25);
            padding: 0 16px;
            font-size: 16px;
            font-family: inherit;
            color: #fff;
            outline: none;
            transition: all .2s;
        }

        .rs-field::placeholder {
            color: rgba(255, 255, 255, .6);
        }

        .rs-field:focus {
            border-color: #f6e3a0;
            background: rgba(0, 0, 0, .35);
            box-shadow: 0 0 0 3px rgba(246, 227, 160, .3);
        }

        .rs-field.h {
            height: 48px;
        }

        .rs-field option {
            color: #000;
        }

        textarea.rs-field {
            resize: none;
            padding: 12px 16px;
        }

        .rs-field.err {
            border-color: #f87171;
        }

        .rs-err {
            margin: 4px 8px 0;
            font-size: 12px;
            color: #fca5a5;
        }

        .rs-toggle {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
        }

        .rs-toggle button {
            min-height: 48px;
            padding: 0 8px;
            border-radius: 16px;
            cursor: pointer;
            font-size: 14px;
            border: 1px solid rgba(246, 227, 160, .4);
            background: rgba(0, 0, 0, .25);
            color: rgba(255, 255, 255, .8);
            transition: all .2s;
        }

        .rs-toggle button.on {
            border-color: transparent;
            background: linear-gradient(135deg, #f6e3a0, #c79a45);
            color: #392708;
            font-weight: 600;
            text-shadow: none;
            box-shadow: 0 6px 14px rgba(0, 0, 0, .3);
        }

        .rs-toggle button:active {
            transform: scale(.95);
        }

        .rs-label {
            display: block;
            margin: 0 8px 4px;
            font-size: 14px;
            color: rgba(255, 255, 255, .8);
        }

        .rs-send {
            height: 48px;
            width: 100%;
            border-radius: 16px;
            font-size: 16px;
            box-shadow: 0 8px 18px rgba(0, 0, 0, .4);
            color: #3a2a06;
        }

        .rs-send[disabled] {
            opacity: .6;
            cursor: wait;
        }

        .rs-done {
            padding: 24px 0;
            text-align: center;
        }

        .rs-done .tick {
            position: relative;
            display: grid;
            place-items: center;
            width: 64px;
            height: 64px;
            margin: 0 auto;
        }

        .rs-done .tick b {
            position: relative;
            display: grid;
            place-items: center;
            width: 64px;
            height: 64px;
            border-radius: 50%;
            background: linear-gradient(135deg, #f6e3a0, #b8862f);
            color: #392708;
            box-shadow: 0 8px 18px rgba(0, 0, 0, .4);
        }

        .rs-done .kx-ringwave {
            inset: 0;
        }

        .wish-head {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            margin: 40px 0 16px;
        }

        .wish-head span {
            height: 1px;
            width: 48px;
        }

        .wish-head span:first-child {
            background: linear-gradient(to right, transparent, #f0d58a);
        }

        .wish-head span:last-child {
            background: linear-gradient(to left, transparent, #f0d58a);
        }

        .wish-head svg {
            fill: #ff8fa3;
            color: #ff8fa3;
        }

        .wish-title {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-bottom: 16px;
            font-size: 14px;
            text-align: center;
        }

        .wish-title b {
            padding: 2px 8px;
            border-radius: 999px;
            background: rgba(246, 227, 160, .25);
            font-size: 11px;
            font-weight: 600;
            color: #f6e3a0;
            -webkit-text-fill-color: #f6e3a0;
        }

        .wish-none {
            text-align: center;
            font-size: 14px;
            color: rgba(255, 255, 255, .7);
        }

        .wish-list {
            position: relative;
            list-style: none;
            display: grid;
            gap: 8px;
            padding-right: 4px;
            overflow: hidden;
            text-align: left;
        }

        .wish-list.open {
            max-height: 20rem;
            overflow-y: auto;
            overscroll-behavior: contain;
            scrollbar-width: thin;
            scrollbar-color: #d9b66f transparent;
        }

        .wish-list li {
            display: flex;
            gap: 12px;
            padding: 12px;
            border-radius: 16px;
            border: 1px solid rgba(246, 227, 160, .25);
            background: rgba(0, 0, 0, .25);
            animation: pop-in .4s cubic-bezier(.2, .9, .2, 1) both;
        }

        @keyframes pop-in {
            from {
                opacity: 0;
                transform: scale(.92);
            }

            to {
                opacity: 1;
                transform: none;
            }
        }

        .wish-av {
            flex: none;
            display: grid;
            place-items: center;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: linear-gradient(135deg, #f6e3a0, #b8862f);
            font-size: 14px;
            font-weight: 700;
            color: #392708;
            text-shadow: none;
        }

        .wish-body {
            min-width: 0;
            flex: 1;
        }

        .wish-row {
            display: flex;
            justify-content: space-between;
            gap: 8px;
        }

        .wish-name {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-weight: 600;
            color: #f6e3a0;
        }

        .wish-ok {
            font-size: 12px;
            font-weight: 600;
            color: #86efac;
        }

        .wish-ok.no {
            color: rgba(255, 255, 255, .5);
        }

        .wish-msg {
            margin-top: 4px;
            font-size: 14px;
            color: rgba(255, 255, 255, .85);
            word-break: break-word;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .wish-fade {
            position: absolute;
            left: 0;
            right: 0;
            bottom: 0;
            height: 64px;
            border-radius: 0 0 16px 16px;
            pointer-events: none;
            background: linear-gradient(to top, rgba(27, 18, 9, .8), transparent);
        }

        .wish-more {
            display: block;
            margin: 12px auto 0;
            padding: 8px 20px;
            border-radius: 999px;
            border: 1px solid rgba(246, 227, 160, .5);
            background: rgba(0, 0, 0, .25);
            font-size: 12px;
            font-weight: 600;
            color: #f6e3a0;
            cursor: pointer;
            text-shadow: none;
        }

        /* =====================================================================
           GIFT + APOLOGY (cream cards)
           ===================================================================== */
        .cream {
            position: relative;
            overflow: hidden;
            padding: 80px 24px;
            text-align: center;
            background: var(--surface) center/cover;
        }

        .cream.ap {
            padding-top: 48px;
            padding-bottom: 96px;
            color: #3b2503;
        }

        .veil {
            position: absolute;
            inset: 0;
            pointer-events: none;
            background: radial-gradient(ellipse at 50% 38%, rgba(255, 244, 214, .55), rgba(251, 246, 234, .15) 62%, transparent);
        }

        .petals {
            position: absolute;
            inset: 0;
            overflow: hidden;
            pointer-events: none;
        }

        .petals i {
            position: absolute;
            top: -24px;
            width: 12px;
            height: 16px;
            opacity: 0;
            background: linear-gradient(135deg, #f6e3a1, #e3bd5a);
            border-radius: 100% 0 100% 0;
            animation: petal-fall linear infinite;
        }

        @keyframes petal-fall {
            0% {
                transform: translate(0, 0) rotate(0);
                opacity: 0;
            }

            12% {
                opacity: .85;
            }

            100% {
                transform: translate(var(--dx), 105vh) rotate(var(--rot));
                opacity: 0;
            }
        }

        .z2 {
            position: relative;
            z-index: 2;
        }

        .gold-card {
            position: relative;
            max-width: 24rem;
            margin: 32px auto 0;
            padding: 3px;
            border-radius: 26px;
            background: var(--foil);
            box-shadow: 0 18px 50px rgba(120, 80, 10, .35);
        }

        .gold-card.float {
            animation: kf-float 7s ease-in-out infinite;
        }

        @keyframes kf-float {
            50% {
                translate: 0 -6px;
            }
        }

        .gold-card-in {
            position: relative;
            overflow: hidden;
            border-radius: 23px;
            padding: 2.4rem 1.5rem 2rem;
            background: linear-gradient(180deg, #fffaf0, #fbf6ea);
        }

        .gold-card-in::before {
            content: "";
            position: absolute;
            inset: 8px;
            border: 1px solid rgba(201, 150, 43, .55);
            border-radius: 17px;
            pointer-events: none;
        }

        .gold-card-in::after {
            content: "";
            position: absolute;
            inset: 0;
            pointer-events: none;
            background: linear-gradient(115deg, transparent 38%, rgba(255, 240, 180, .45) 50%, transparent 62%);
            transform: translateX(-130%);
            animation: kf-shine 6s ease-in-out infinite 1.2s;
        }

        @keyframes kf-shine {

            0%,
            55% {
                transform: translateX(-130%);
            }

            100% {
                transform: translateX(130%);
            }
        }

        .g-corner {
            position: absolute;
            z-index: 2;
            opacity: .95;
        }

        .gcn-tl {
            top: 12px;
            left: 12px;
        }

        .gcn-tr {
            top: 12px;
            right: 12px;
        }

        .gcn-bl {
            bottom: 12px;
            left: 12px;
        }

        .gcn-br {
            bottom: 12px;
            right: 12px;
        }

        .kf-sub {
            max-width: 20rem;
            margin: 0 auto;
            font-size: .9rem;
            line-height: 1.9;
            opacity: .85;
        }

        .kf-qr {
            position: relative;
            width: 12.5rem;
            max-width: 100%;
            margin: 0 auto;
            padding: 12px;
            background: #fff;
            border: 2px solid #e3bd5a;
            border-radius: 14px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, .18);
        }

        .kf-qr img {
            display: block;
            width: 100%;
            height: auto;
            aspect-ratio: 1/1;
            object-fit: contain;
            background: #fff;
        }

        .kf-scan {
            margin: .7rem 0 1.2rem;
            font-size: .78rem;
            letter-spacing: .08em;
            opacity: .7;
        }

        .kf-bank {
            font-size: .72rem;
            letter-spacing: .32em;
            color: #a8741a;
            font-weight: 600;
        }

        .kf-label {
            margin-top: 1rem;
            font-size: .7rem;
            letter-spacing: .12em;
            opacity: .65;
        }

        .kf-name {
            margin-top: .15rem;
            font-size: .95rem;
            font-weight: 600;
        }

        .kf-num {
            margin-top: .15rem;
            font-size: 1.9rem;
            font-weight: 700;
            letter-spacing: .04em;
            line-height: 1.5;
            background: var(--foil);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            background-size: 200% 100%;
            animation: kf-foil 5s linear infinite;
        }

        @keyframes kf-foil {
            to {
                background-position: 200% 0;
            }
        }

        .kf-divider {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 1.1rem auto 0;
            max-width: 12rem;
        }

        .kf-divider span {
            flex: 1;
            height: 1px;
            background: linear-gradient(90deg, transparent, #e3bd5a, transparent);
        }

        .kf-divider b {
            width: 7px;
            height: 7px;
            transform: rotate(45deg);
            background: #e3bd5a;
        }

        .kf-btn {
            position: relative;
            display: inline-flex;
            align-items: center;
            gap: .5rem;
            min-height: 46px;
            margin-top: 1.3rem;
            padding: 0 1.7rem;
            border-radius: 999px;
            border: 1.5px solid #e3bd5a;
            cursor: pointer;
            color: #7a4f08;
            font-weight: 600;
            font-size: .9rem;
            background: transparent;
            overflow: visible;
            transition: background .35s, color .35s, transform .2s, box-shadow .35s;
        }

        .kf-btn:hover,
        .kf-btn.done {
            background: var(--foil);
            color: #3b2503;
            box-shadow: 0 8px 22px rgba(201, 150, 43, .45);
        }

        .kf-btn:active {
            transform: scale(.94);
        }

        .ap-bud {
            display: block;
            margin: 0 auto .6rem;
            filter: drop-shadow(0 0 6px rgba(227, 189, 90, .6));
            animation: ap-breathe 4.5s ease-in-out infinite;
            transform-origin: 50% 90%;
        }

        @keyframes ap-breathe {
            50% {
                transform: scale(1.08);
                filter: drop-shadow(0 0 12px rgba(255, 226, 140, .95));
            }
        }

        .ap-divider {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: .9rem auto;
            max-width: 11rem;
        }

        .ap-divider span {
            flex: 1;
            height: 1px;
            background: linear-gradient(90deg, transparent, #e3bd5a, transparent);
        }

        .ap-divider b {
            width: 7px;
            height: 7px;
            transform: rotate(45deg);
            background: #e3bd5a;
        }

        .ap-line {
            margin: 0 0 .35rem;
            font-size: .95rem;
            line-height: 2.1;
            opacity: 0;
            transform: translateY(16px);
            filter: blur(5px);
            transition: opacity .9s ease, transform 1s cubic-bezier(.2, .8, .2, 1), filter .9s ease;
            transition-delay: calc(.7s + var(--i) * .45s);
        }

        .ap-shown .ap-line {
            opacity: .92;
            transform: none;
            filter: none;
        }

        .ap-card-w {
            opacity: 0;
            transform: translateY(40px) scale(.95);
            transition: opacity .9s cubic-bezier(.2, .8, .2, 1), transform 1s cubic-bezier(.2, .8, .2, 1);
        }

        .ap-shown .ap-card-w {
            opacity: 1;
            transform: none;
        }

        .gold-card.ap-c {
            border-radius: 22px;
            margin-top: 0;
            box-shadow: 0 16px 44px rgba(120, 80, 10, .3);
        }

        .gold-card.ap-c .gold-card-in {
            border-radius: 19px;
            padding: 2.2rem 1.6rem 2rem;
        }

        /* =====================================================================
           THANKS
           ===================================================================== */
        .th-bloom {
            display: block;
            width: 11rem;
            margin: 0 auto 20px;
            color: #f0d58c;
        }

        .g-petal {
            transform-box: fill-box;
            transform-origin: 50% 100%;
            transform: scaleY(0);
            opacity: 0;
        }

        .played .g-petal {
            animation: kf-bloom .8s cubic-bezier(.2, .9, .3, 1.2) both;
            animation-delay: calc(var(--i) * 110ms + 200ms);
        }

        @keyframes kf-bloom {
            from {
                opacity: 0;
                transform: scaleY(0);
            }

            to {
                opacity: 1;
                transform: scaleY(1);
            }
        }

        .th-title {
            font-size: clamp(1.6rem, 8vw, 2.25rem);
            line-height: 1.7;
        }

        .th-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            min-height: 44px;
            margin-top: 32px;
            padding: 0 20px;
            border-radius: 999px;
            cursor: pointer;
            border: 1px solid rgba(255, 255, 255, .6);
            background: transparent;
            color: #fff;
            font-size: 14px;
            transition: background .2s, transform .2s;
        }

        .th-btn:hover {
            background: rgba(255, 255, 255, .1);
        }

        .th-btn:active {
            transform: scale(.95);
        }

        /* music button */
        .g-music {
            position: fixed;
            right: 14px;
            bottom: 14px;
            z-index: 60;
            display: grid;
            place-items: center;
            width: 44px;
            height: 44px;
            border: 0;
            border-radius: 50%;
            cursor: pointer;
            background: #7a1f2b;
            color: #e6b84a;
            box-shadow: 0 6px 16px rgba(0, 0, 0, .35);
            opacity: .6;
        }

        .g-music.on {
            opacity: 1;
            animation: g-spin 6s linear infinite;
        }

        .g-music.hide {
            display: none;
        }

        .sr {
            position: absolute;
            width: 1px;
            height: 1px;
            overflow: hidden;
            clip: rect(0 0 0 0);
        }

        @media (prefers-reduced-motion: reduce) {

            .gw *,
            .gw *::before,
            .gw *::after,
            .gc *,
            .gc-door {
                animation-duration: .01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: .01ms !important;
                transition-delay: 0ms !important;
            }

            .kx-slide,
            .kx-text,
            .rv,
            .kg-tile,
            .ap-line,
            .ap-card-w,
            .kx-heart-wrap,
            .g-reveal,
            .royal-enter {
                opacity: 1 !important;
                transform: none !important;
            }

            .kx-divline {
                transform: none !important;
            }
        }
    </style>
